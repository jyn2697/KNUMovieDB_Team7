-- #1
SELECT COUNT(ID)
FROM ACCOUNT
WHERE NOT Membership_ID = 4;


-- #2
SELECT Name, Address
FROM ACCOUNT
WHERE Membership_ID = 4;


-- #3
select count(*)
from(
  select a_id, count(*)
  from rating
  group by A_ID
  having count(*) >= 5) A
order by A.a_id;


-- #4
SELECT count(M.id)
FROM GENRE G, GENRE_TYPE GT, MOVIE M
WHERE G.Type = 'Romance'
AND G.ID = GT.G_ID
AND GT.M_ID = M.ID
and m.released_date like '20%';


-- #5
select count(id)
from movie
where released_date between '18/10/17' and '20/10/17';


-- #6 -- 너무 길어 소수점 아래 두번째 자리까지만 표현
select trunc(avg(score_avg), 2)
from movie
where released_date between '15/10/07' and '20/10/17';


-- #7
select count(id)
from movie
where RUNNING_TIME >= 100;


-- #8
select m.title, m.score_avg
from movie m
inner join genre_type gt
on gt.m_id = m.id
inner join genre g
on g.id = gt.g_id
where (g.type = 'Action' or g.type = 'Comedy')
and m.score_avg = (select max(score_avg)
                    from movie m
                    inner join genre_type gt
                    on gt.m_id = m.id
                    inner join genre g
                    on g.id = gt.g_id
                    where g.type = 'Action' or g.type = 'Comedy');


-- #9
select count(A.t_s_id)
from (select T_S_id, count(M_id) 
from episode
group by T_S_id
having count(M_id)>=10) A;


-- #10
with a as(
select a.id, a.name, 2020-extract(year from a.Bdate)+1 age
from account a
),
b as(
select id from account
minus
select a_id from rating
)
select a.name, a.age
from a
inner join b
on a.id = b.id;


-- #11
with co as
(select a_id, count(1) c
from rating
group by a_id
),
a as
(select id
from account a
inner join co
on co.a_id = a.id
where a.job is not null
and co.c = 1
)
select count(*)
from a;


-- #12
select m.id, a.name
from movie m
inner join casting_list cl
on cl.m_id = m.id
inner join actor a
on a.id = cl.actor_id
where score_avg >= 8;


-- #13
select distinct m.title, a.name
from movie m
inner join genre_type gt
on gt.m_id = m.id
inner join genre g
on g.id = gt.g_id
inner join movie_type mt
on mt.id = m.type_id
inner join casting_list cl
on cl.m_id = m.id
inner join actor a
on cl.actor_id = a.id
where g.type != 'Action'
and m.score_avg < 6
and extract(year from m.released_date) >= 2010
and mt.type = 'Movie'
order by m.title;


-- #14
select count(id)
from movie m
where extract(year from m.RELEASED_DATE)=(select max(extract(year from a.Bdate))
from account a
left join membership m
on a.membership_id = m.id
where m.type = 'Prime');


-- #15
with ab as
(select r.a_id, count(r.id)
from rating r
inner join account a
on a.id = r.a_id
inner join membership mem
on mem.id = a.membership_id
where mem.type = 'Premium'
group by r.a_id
having count(r.id)>=10
)
select max(extract(year from m.released_date))
from ab
inner join rating r
on ab.a_id = r.a_id
inner join movie m
on m.id = r.m_id
inner join movie_type mt
on mt.id = m.type_id
where mt.type != 'TV Series'
and m.score_avg < 8
order by m.id;


-- #16
with mo as
(select id, score_avg
from movie
where score_avg = (select max(score_avg)
                    from movie)
),
ac as(
select distinct a_id id
from mo
inner join rating r
on mo.id = r.m_id
)
select a.Phone
from ac
inner join account a
on ac.id = a.id
where Address is not null
and length(a.address) = (select max(length(a.address))
        from ac
        inner join account a
        on ac.id = a.id
        where Address is not null);


-- #17
with ac as
(select actor_id, count(*), dense_rank() over (order by count(*) desc) as rk
from casting_list
group by actor_id
),
av as (
select ac.actor_id, cl.m_id, m.released_date, m.score_avg
from ac
inner join CASTING_LIST cl
on ac.actor_id = cl.actor_id
inner join movie m
on cl.m_id = m.id
where rk = 3
and m.released_date = (select min(m.released_date)
                      from ac
                      inner join CASTING_LIST cl
                      on ac.actor_id = cl.actor_id
                      inner join movie m
                      on cl.m_id = m.id
                      where rk = 3)
)
select count(id)
from movie
where score_avg = (select score_avg from av)+1 
  or score_avg = (select score_avg from av)-1;


-- #18
with v as
(SELECT v.m_id, COUNT(*) 
FROM version v
inner join movie m
on v.m_id = m.id
inner join movie_type mt
on mt.id = m.type_id
where m_id is not null
and mt.type = 'Movie' or mt.type = 'TV Series'
GROUP BY m_id
having count(*) between 5 and 10
order by m_id
),
x as(
select v.m_id, count(cl.actor_id)
from v
inner join casting_list cl
on v.m_id = cl.m_id
group by v.m_id
having count(cl.actor_id) <=5
)
select trunc(avg(m.score_avg),2)
from x
inner join movie m
on x.m_id = m.id;


-- #19
with mo as
(select id, score_avg
from movie
where score_avg = (select max(score_avg)
                    from movie)
),
ac as(
select distinct a.id
from mo
inner join casting_list cl
on mo.id = cl.m_id 
inner join actor a
on a.id = cl.actor_id),
mo2 as(
select distinct cl.m_id
from ac
inner join casting_list cl
on cl.actor_id = ac.id
),
ran as
(
select m.id, score_avg, DENSE_RANK() OVER (ORDER BY score_avg DESC ) as rk
from mo2
inner join movie m
on mo2.m_id = m.id
order by score_avg),
run as(
select distinct m.RUNNING_TIME
from ran
inner join movie m
on ran.id = m.id
where ran.rk = 2
)
select m.title
from run
inner join movie m
on run.running_time = m.running_time;


-- #20
with male as(
select r.a_id a_id, r.m_id
from rating r
left join account a 
on a.id = r.a_id
where a.gender = 'M'
and r.m_id = (select r.m_id 
              from rating r
              left join account a
              on a.id = r.a_id
              where a.gender = 'F'
              group by r.m_id
              having count(r.id) = (select max(count(r1.id)) max
                                    from rating r1
                                    left join account a 
                                    on a.id = r1.a_id
                                    where a.gender = 'F'
                                    group by r1.m_id)) 
),
mg as(
select count(r.id) c, g.type
from rating r
inner join male
on r.a_id = male.a_id
inner join genre_type gt
on gt.m_id = r.m_id
inner join genre g
on g.id = gt.g_id
group by g.type
),
rat as(
select m.id m, g.type
from movie m
inner join genre_type gt
on gt.m_id = m.id
inner join genre g
on g.id = gt.g_id
where g.type = (
select mg.type
from mg
where mg.c = (select max(mg.c)
              from mg)
)
),
su as( 
select r1.m, count(r.id) c
from rat r1
left join rating r
on r1.m = r.m_id
group by r1.m
),
da as(
select su.m, su.c
from su
where su.c = (select min(su.c)
              from su)
),
ye as(
select da.m, extract(year from m.released_date) y
from da
inner join movie m
on da.m = m.id
)
select distinct ye.y, a.name
from ye, account a
where ye.y = extract(year from a.Bdate);
