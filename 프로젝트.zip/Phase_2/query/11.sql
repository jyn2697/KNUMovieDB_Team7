--11
set define off;

insert into membership values (1, 'Basic');
insert into membership values (2, 'Premium');
insert into membership values (3, 'Prime');
insert into membership values (4, 'Administrator');
insert into membership values (5, 'Free');

commit;