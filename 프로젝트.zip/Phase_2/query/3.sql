--3
set define off;

insert into genre values (1, 'Action');
insert into genre values (2, 'Thriller');
insert into genre values (3, 'Adventure');
insert into genre values (4, 'Romance');
insert into genre values (5, 'Fantasy');
insert into genre values (6, 'Comedy');
insert into genre values (7, 'Drama');

commit;