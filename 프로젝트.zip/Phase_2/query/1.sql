--1
set define off;

insert into movie_type values (1, 'Movie');
insert into movie_type values (2, 'TV Series');
insert into movie_type values (3, 'KnuMovieDB Original');

commit;