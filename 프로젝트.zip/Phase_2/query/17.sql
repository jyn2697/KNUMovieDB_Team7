--17
set define off;

INSERT INTO TV_SERIES VALUES ('1','Gray Anatomy');
INSERT INTO TV_SERIES VALUES ('2','Anne with an E');
INSERT INTO TV_SERIES VALUES ('3','Outlander');
INSERT INTO TV_SERIES VALUES ('4','Cable Girls');
INSERT INTO TV_SERIES VALUES ('5','Girls from Ipanema');
INSERT INTO TV_SERIES VALUES ('6','Kingdom');
INSERT INTO TV_SERIES VALUES ('7','Something in the Rain');
INSERT INTO TV_SERIES VALUES ('8','When the Camellia Blooms');
INSERT INTO TV_SERIES VALUES ('9','Persona');
INSERT INTO TV_SERIES VALUES ('10','Alexa & Katie');
INSERT INTO TV_SERIES VALUES ('11','Malibu Rescue: The Series');
INSERT INTO TV_SERIES VALUES ('12','Team Kaylie');
INSERT INTO TV_SERIES VALUES ('13','Prince of Peoria');
INSERT INTO TV_SERIES VALUES ('14','The Big Show Show');
INSERT INTO TV_SERIES VALUES ('15','The Big Bang Theory');
INSERT INTO TV_SERIES VALUES ('16','Guardian: The Lonely and Great God');
INSERT INTO TV_SERIES VALUES ('17','Reply 1997');
INSERT INTO TV_SERIES VALUES ('18','The School Nurse Files');
INSERT INTO TV_SERIES VALUES ('19','Extracurricular');
INSERT INTO TV_SERIES VALUES ('20','Stranger Things');

commit;