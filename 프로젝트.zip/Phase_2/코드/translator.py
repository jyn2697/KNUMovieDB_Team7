# https://codechacha.com/ko/python-google-translate/ - 번역기
# https://gist.github.com/carlopires/1262033/c52ef0f7ce4f58108619508308372edd8d0bd518 - 언어 코드
import openpyxl
from googletrans import Translator

wb = openpyxl.load_workbook('TV_SERIES.xlsx')

sheet_en = wb['en']

language = ["ko", 'ja', 'it', 'vi', 'ar', 'es']

translator = Translator()
for lang in language:
    sheet = wb[lang]
    for i in range(2, 22):
        line = sheet_en.cell(row=i, column=2).value

        result = translator.translate(line, dest=lang)

        print(lang, result.text)
        sheet.cell(row=i, column=1).value = i-1
        sheet.cell(row=i, column=2).value = result.text

    # 하나만 번역할 때
    # line = sheet_en.cell(row=295, column=2).value
    #
    # result = translator.translate(line, dest=lang)
    # print(lang, result.text)
    # sheet.cell(row=295, column=2).value = result.text
    wb.save('TV_SERIES.xlsx')