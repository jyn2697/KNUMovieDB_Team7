import openpyxl
import random

wb_director = openpyxl.load_workbook('WRITER.xlsx')
sheet_director = wb_director.active

wb = openpyxl.load_workbook('CREW_OF_WRITER.xlsx')
sheet = wb.active

row_nbr = 2

for i in range(1, 411):
    if i % 5 == 0:
        rand = random.randrange(1, 3)
    else:
        rand = 1

    for j in range(rand):
        sheet.cell(row=row_nbr, column=1).value = i
        sheet.cell(row=row_nbr, column=2).value = sheet_director.cell(row=random.randrange(2, 85), column=2).value
        row_nbr += 1

wb.save('CREW_OF_WRITER.xlsx')