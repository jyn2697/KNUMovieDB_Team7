import random
import openpyxl

wb = openpyxl.load_workbook('VIEW.xlsx')
sheet = wb.active
row_nbr = 2

for i in range(1, 411):
    rand = random.randrange(0, 30)

    rand_list = random.sample(range(1, 164), rand)

    for j in rand_list:
        sheet.cell(row=row_nbr, column=1).value = i
        sheet.cell(row=row_nbr, column=2).value = j

        row_nbr += 1

wb.save('VIEW.xlsx')