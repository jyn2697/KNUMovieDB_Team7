# https://codechacha.com/ko/python-google-translate/ - 번역기
# https://gist.github.com/carlopires/1262033/c52ef0f7ce4f58108619508308372edd8d0bd518 - 언어 코드
import openpyxl
from googletrans import Translator

wb = openpyxl.load_workbook('VERSION.xlsx')
wb2 = openpyxl.load_workbook('VERSION2.xlsx')
sheet = wb.active
sheet2 = wb2.active
#sheet_en = wb['en']

#language = ["ko", 'ja', 'it', 'vi', 'ar', 'es']

translator = Translator()
# for lang in language:
#     sheet = wb[lang]
#     for i in range(2, 22):
#         line = sheet_en.cell(row=i, column=2).value
#
#         result = translator.translate(line, dest=lang)
#
#         print(lang, result.text)
#         sheet.cell(row=i, column=1).value = i-1
#         sheet.cell(row=i, column=2).value = result.text
#
#     # 하나만 번역할 때
#     # line = sheet_en.cell(row=295, column=2).value
#     #
#     # result = translator.translate(line, dest=lang)
#     # print(lang, result.text)
#     # sheet.cell(row=295, column=2).value = result.text
#     wb.save('TV_SERIES.xlsx')

row_nbr = 2
while row_nbr <= 2630:
    line = sheet.cell(row=row_nbr, column=4).value

    result = translator.translate(line, dest='en')
    print(row_nbr, result.text)
    sheet2.cell(row=row_nbr, column=4).value = result.text
    row_nbr += 1

wb.save('VERSION2.xlsx')