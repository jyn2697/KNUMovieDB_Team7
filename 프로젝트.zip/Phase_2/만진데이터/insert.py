import openpyxl


table_list = ["ACCOUNT"]
    # "MOVIE", "GENRE_TYPE", "PRODUCTION_COMPANY", "MAKING", "DISTRIBUTION_COMPANY", "DISTRIBUTING",
    #           "ACTOR", "CASTING_LIST", "WRITER", "CREW_OF_WRITER", "DIRECTOR", "CREW_OF_DIRECTOR", "VERSION",
    #           "LIKES", "VIEWS", "RATING", "TV_SERIES", "EPISODE", "ACCOUNT"]

for i in table_list:
    txt_file = i + ".txt"
    f = open(txt_file, 'w', encoding="UTF8")

    excel = i + ".xlsx"

    wb = openpyxl.load_workbook(excel)
    sheet = wb.active

    # attribute 확인
    col_nbr = 1
    attribute_list = []
    while sheet.cell(row=1, column=col_nbr).value != None:
        attribute_list.append(sheet.cell(row=1, column=col_nbr).value)
        col_nbr += 1

    # insert문 작성
    row_nbr = 2

    print(i)
    while sheet.cell(row=row_nbr, column=1).value != None:
        query = "INSERT INTO " + i + " VALUES ("
        for j in range(1, col_nbr):
            string = str(sheet.cell(row=row_nbr, column=j).value)

            # plot이 너무 길어서 안들어가는거 방지
            if len(string) > 100:
                string = string[:100] + "..."

            if j < col_nbr - 1:
                # NULL 은 '' 로 둘러싸면 안됌
                if string == "NULL":
                    query = query + string + ","
                else:
                    query = query + "\'" + string + "\',"
            else:
                if string == "NULL":
                    query = query + string + ");\n"
                else:
                    query = query + "\'" + string + "\');\n"
        row_nbr += 1
        print(query)
        f.write(query)

    f.close()