import random
import openpyxl

wb = openpyxl.load_workbook('LIKES.xlsx')
sheet = wb.active
row_nbr = 2
#
# # 0 ~ 12번씩 평가 -> 20, 20, 20, 20, 20, 10, 10, 10, 10, 10, 4, 4, 5명씩
# list = random.sample(range(1, 164), 163)
# rate_arr = [20, 40, 60, 80, 100, 110, 120, 130, 140, 150, 154, 158, 163]
# rating_nbr = 0
# count = 0
# row_nbr = 2
#
# for person in list:
#     rand = random.sample(range(1, 412), rating_nbr)
#
#     for i in rand:
#         sheet.cell(row=row_nbr, column=1).value = i
#         sheet.cell(row=row_nbr, column=2).value = person
#         row_nbr += 1
#     if count >= rate_arr[rating_nbr]:
#         rating_nbr += 1
#     count += 1
#
# wb.save('VIEWS2.xlsx')
# 영화가 411개이므로
#
for i in range(1, 411):
    rand = random.randrange(0, 5)

    rand_list = random.sample(range(1, 164), rand)

    for j in rand_list:
        sheet.cell(row=row_nbr, column=1).value = i
        sheet.cell(row=row_nbr, column=2).value = j

        row_nbr += 1

wb.save('LIKES.xlsx')