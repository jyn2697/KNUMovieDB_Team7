import random
import openpyxl

wb_view = openpyxl.load_workbook('VIEWS2.xlsx')
sheet_view = wb_view.active

wb_comment = openpyxl.load_workbook('comment.xlsx')
sheet_comment_pos = wb_comment['positive']
sheet_comment_neg = wb_comment['negative']

wb_rating = openpyxl.load_workbook('RATING.xlsx')
sheet_rating = wb_rating.active

movie_nbr = 1
row_nbr = 2

for i in range(682):
    rand = random.randrange(0, 2)
    rand_nbr = random.randrange(1, 16)

    # ID, Score, Comment, AccountID, M_ID 순서로 넣기
    if rand == 0:       # 긍정평
        sheet_rating.cell(row=row_nbr, column=1).value = row_nbr - 1
        sheet_rating.cell(row=row_nbr, column=2).value = random.randrange(6, 11)
        sheet_rating.cell(row=row_nbr, column=3).value = sheet_comment_pos.cell(row=rand_nbr, column=1).value
        sheet_rating.cell(row=row_nbr, column=4).value = sheet_view.cell(row=row_nbr, column=2).value
        sheet_rating.cell(row=row_nbr, column=5).value = sheet_view.cell(row=row_nbr, column=1).value
    else:               # 부정평
        sheet_rating.cell(row=row_nbr, column=1).value = row_nbr - 1
        sheet_rating.cell(row=row_nbr, column=2).value = random.randrange(1, 6)
        sheet_rating.cell(row=row_nbr, column=3).value = sheet_comment_neg.cell(row=rand_nbr, column=1).value
        sheet_rating.cell(row=row_nbr, column=4).value = sheet_view.cell(row=row_nbr, column=2).value
        sheet_rating.cell(row=row_nbr, column=5).value = sheet_view.cell(row=row_nbr, column=1).value

    row_nbr += 1

wb_rating.save('RATING.xlsx');
