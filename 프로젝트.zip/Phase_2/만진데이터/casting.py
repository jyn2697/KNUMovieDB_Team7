import openpyxl
import random

wb_movie = openpyxl.load_workbook('MOVIE.xlsx')
sheet_movie = wb_movie.active

wb_actor = openpyxl.load_workbook('ACTOR.xlsx')
sheet_actor = wb_actor.active

wb = openpyxl.load_workbook('CASTING_LIST.xlsx')
sheet = wb.active

row_nbr = 2
for i in range(1, 411):
    rand = random.randrange(3, 8)

    actor_list = random.sample(range(3, 313), rand)
    count = 0
    for j in actor_list:
        sheet.cell(row=row_nbr, column=1).value = i
        sheet.cell(row=row_nbr, column=2).value = j

        if count <= 2:
            sheet.cell(row=row_nbr, column=3).value = "L"
        else:
            sheet.cell(row=row_nbr, column=3).value = "S"

        count += 1
        row_nbr += 1

wb.save('CASTING_LIST.xlsx')