import openpyxl

wb1 = openpyxl.load_workbook('VERSION.xlsx')
wb2 = openpyxl.load_workbook('VERSION2.xlsx')

sheet1 = wb1.active
sheet2 = wb2.active

row_nbr = 2531
while row_nbr <= 2630:
    nbr = sheet1.cell(row=row_nbr, column=7).value
    sheet2.cell(row=row_nbr, column=4).value = sheet1.cell(row=nbr+1, column=4).value
    print(sheet2.cell(row=row_nbr, column=4).value)

    row_nbr += 1

wb2.save('VERSION2.xlsx')