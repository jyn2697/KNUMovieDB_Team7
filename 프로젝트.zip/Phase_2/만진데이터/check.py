query = "123"
query = query + "\"" + query + "\","
print(query)