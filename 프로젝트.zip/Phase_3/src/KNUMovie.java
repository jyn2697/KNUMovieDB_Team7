import java.sql.*;

class KNUMovie {
	
	public static final String URL = "jdbc:oracle:thin:@localhost:1521:orcl";
	public static final String USER_COMPANY ="test2";
	public static final String USER_PASSWD ="test2";
	public static Connection conn = null; // Connection object
	public static Statement stmt = null;   // Statement object(SQL ����)
	public static PreparedStatement pstmt;
	public static ResultSet rs;
	public static void main(String[] args) {

		try {
	    	// Load a JDBC driver for Oracle DBMS
	    	Class.forName("oracle.jdbc.driver.OracleDriver");
	    	// Get a Connection object 
	    	System.out.println("Success!");
	    } catch(ClassNotFoundException e) {
	    	System.err.println("error = " + e.getMessage());
	    	System.exit(1);
	    }

	    // Make a connection
	    try{
	    	conn = DriverManager.getConnection(URL, USER_COMPANY, USER_PASSWD); 
	    } catch(SQLException ex) {
	    	ex.printStackTrace();
	        System.err.println("Cannot get a connection: " + ex.getMessage());
	        System.exit(1);
	    }
	    
	    new loginView();
	}
}
