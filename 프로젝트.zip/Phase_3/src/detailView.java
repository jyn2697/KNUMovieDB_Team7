import java.awt.Desktop;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.ArrayList;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class detailView extends JFrame{
	private KNUMovie mv;
	
	public detailView(int userPrivateID, String movieTitle, int movieID) {
		JPanel panel = new JPanel();								// panel�� �̿��� frame�� 
		panel.setLayout(null);										// ���ϴ� ��ġ�� ���ϴ� ������ �ִ´�
		
		
		// ��Ÿ�� ������ DB���� �޾ƿ´�
		String runningTime = "";
		String releasedDate = "";
		String scoreAvg = "";
		String plot = "";
		ArrayList<String> actorName = new ArrayList<String>();
		ArrayList<String> directorName = new ArrayList<String>();
		ArrayList<String> writerName = new ArrayList<String>();
		ArrayList<String> genreList = new ArrayList<String>();
		String movieType = "";
		
		try {
			mv.stmt = mv.conn.createStatement();	// DB�� ����
	        mv.conn.setAutoCommit(false); 			// auto-commit disabled
	        
	        // ��ȭ �󿵽ð�, �󿵳⵵, ���� ���, �ٰŸ�
	        String sql = "SELECT RUNNING_TIME, TO_CHAR(RELEASED_DATE, 'YYYY'), SCORE_AVG, PLOT "
	        			+ "FROM MOVIE "
	        			+ "WHERE ID = " + movieID;
	        						 
	        mv.pstmt = mv.conn.prepareStatement(sql);
            mv.rs = mv.pstmt.executeQuery();
            
            while(mv.rs.next()) {
            	runningTime = mv.rs.getString(1);
            	releasedDate = mv.rs.getString(2);
            	scoreAvg = mv.rs.getString(3);
            	plot = mv.rs.getString(4);
            }
            
            
            // �����
            sql = "SELECT A.NAME "
            	+ "FROM ACTOR A "
            	+ "JOIN CASTING_LIST C "
            	+ "  ON A.ID = C.ACTOR_ID "
            	+ "WHERE C.M_ID = " + movieID;
            
            mv.pstmt = mv.conn.prepareStatement(sql);
            mv.rs = mv.pstmt.executeQuery();
            
            while(mv.rs.next())
            	actorName.add(mv.rs.getString(1));
            
            
            // ������
            sql = "SELECT D.NAME "
            	+ "FROM DIRECTOR D "
            	+ "JOIN CREW_OF_DIRECTOR C "
            	+ "  ON D.ID = C.D_ID "
            	+ "WHERE C.M_ID = " + movieID;
            
            mv.pstmt = mv.conn.prepareStatement(sql);
            mv.rs = mv.pstmt.executeQuery();
            
            while(mv.rs.next())
            	directorName.add(mv.rs.getString(1));
            
            
            // �۰� �̸�
            sql = "SELECT W.NAME "
            	+ "FROM WRITER W "
            	+ "JOIN CREW_OF_WRITER C "
            	+ "  ON W.ID = C.W_ID "
            	+ "WHERE C.M_ID = " + movieID;
            
            mv.pstmt = mv.conn.prepareStatement(sql);
            mv.rs = mv.pstmt.executeQuery();
            
            while(mv.rs.next())
            	writerName.add(mv.rs.getString(1));
            
            
            
            // �帣
            sql = "SELECT G.TYPE "
            	+ "FROM GENRE G "
            	+ "JOIN GENRE_TYPE GT "
            	+ "  ON G.ID = GT.G_ID "
            	+ "WHERE GT.M_ID = "  + movieID;
            
            mv.pstmt = mv.conn.prepareStatement(sql);
            mv.rs = mv.pstmt.executeQuery();
            
            while(mv.rs.next()) 
            	genreList.add(mv.rs.getString(1));
            
            
            // ������ Ÿ��
            sql = "SELECT MT.TYPE "
            	+ "FROM MOVIE_TYPE MT "
            	+ "JOIN MOVIE M "
            	+ "  ON M.TYPE_ID = MT.ID "
            	+ "WHERE M.ID = " +  movieID;
                
                mv.pstmt = mv.conn.prepareStatement(sql);
                mv.rs = mv.pstmt.executeQuery();
                
                while(mv.rs.next()) 
                	movieType = mv.rs.getString(1);
            
            
		} catch(Exception e) {
			e.printStackTrace();
		}
			
		
		
		
		// ��ȭ ����
		JLabel title = new JLabel(movieTitle);
		title.setBounds(100, 50, 100, 50);
		panel.add(title);
		
		// ��ȭ ��� ��ư
		ImageIcon imgPlay = new ImageIcon("images/�����ư.png");
		Image img = imgPlay.getImage();
		Image changeImg = img.getScaledInstance(50, 50, Image.SCALE_SMOOTH);
		imgPlay = new ImageIcon(changeImg);
		
		JButton play = new JButton(imgPlay);
		play.setBounds(250, 50, 50, 50);
		panel.add(play);
		
		// ���ϱ� ��ư
		JButton evaluate = new JButton("��");
		evaluate.setBounds(350, 50, 100, 25);
		panel.add(evaluate);
		evaluate.addActionListener(new ActionListener() {
    		@Override
    		public void actionPerformed(ActionEvent e) {
    			new evaluationView(userPrivateID, movieTitle, movieID);			// �ش� ��ȭ ���ϱ�� �ѱ�
    		}
    	});
		
		
		// �����ϱ� ��ư
		try {
			mv.stmt = mv.conn.createStatement();	// DB�� ����
	        mv.conn.setAutoCommit(false); 			// auto-commit disabled
	        
	        String sql = "SELECT Membership_ID FROM ACCOUNT WHERE ID = " + userPrivateID;
        						 
	        mv.pstmt = mv.conn.prepareStatement(sql);
	        mv.rs = mv.pstmt.executeQuery();
	        int membershipNbr = 0;
	        while(mv.rs.next())
	        	membershipNbr = Integer.parseInt(mv.rs.getString(1));
	        		        
			if(membershipNbr == 4) {
				JButton revise = new JButton("����");
				revise.setBounds(350, 80, 100, 25);
				panel.add(revise);
				revise.addActionListener(new ActionListener() {
		    		@Override
		    		public void actionPerformed(ActionEvent e) {
		    			new updateMovieView(userPrivateID, movieTitle, movieID);			// �ش� ��ȭ ���ϱ�� �ѱ�
		    			dispose();
		    		}
		    	});
			}
		} catch(Exception e1) {
			e1.printStackTrace();
		}
		
		
		
		// ���� ���
		JLabel averageText = new JLabel("���� ���");
		averageText.setBounds(100, 150, 100, 50);
		panel.add(averageText);
		
		JLabel average = new JLabel(scoreAvg);
		average.setBounds(250, 150, 100, 50);
		panel.add(average);
		
		// ���
		JLabel actorText = new JLabel("���");
		actorText.setBounds(100, 200, 100, 50);
		panel.add(actorText);
		
		for(int i = 0; i < 2; i++) {
			JLabel actor = new JLabel(actorName.get(i));
			actor.setBounds(250, (200 + i*30), 200, 50);
			panel.add(actor);
		}
		
		// ����
		JLabel directorText = new JLabel("����");
		directorText.setBounds(100, 280, 100, 50);
		panel.add(directorText);
		
		JLabel director = new JLabel(directorName.get(0));
		director.setBounds(250, 280, 100, 50);
		panel.add(director);
		
		// �۰�
		JLabel writerText = new JLabel("�۰�");
		writerText.setBounds(100, 330, 100, 50);
		panel.add(writerText);
		
		JLabel writer = new JLabel(writerName.get(0));
		writer.setBounds(250, 330, 100, 50);
		panel.add(writer);
	
		// �󿵳⵵
		JLabel releasedDateText = new JLabel("�󿵳⵵");
		releasedDateText.setBounds(100, 380, 100, 50);
		panel.add(releasedDateText);
		
		JLabel Date = new JLabel(releasedDate);
		Date.setBounds(250, 380, 100, 50);
		panel.add(Date);
		
		// �󿵽ð�
		JLabel runningTimeText = new JLabel("�󿵽ð�");
		runningTimeText.setBounds(100, 430, 100, 50);
		panel.add(runningTimeText);
		
		JLabel showRunningTime = new JLabel(runningTime);
		showRunningTime.setBounds(250, 430, 100, 50);
		panel.add(showRunningTime);
		
		
		// ���� type
		JLabel typeText = new JLabel("���� ����");
		typeText.setBounds(100, 480, 100, 50);
		panel.add(typeText);
		
		JLabel type = new JLabel(movieType);
		type.setBounds(250, 480, 100, 50);
		panel.add(type);
		
		// �帣
		JLabel genreText = new JLabel("�帣");
		genreText.setBounds(100, 530, 100, 50);
		panel.add(genreText);
		
		for(int i = 0; i < genreList.size(); i++) {
			JLabel genre = new JLabel(genreList.get(i));
			genre.setBounds(250, 530 + i*30, 100, 50);
			panel.add(genre);
		}
		
		// �ٰŸ�
		int last_row = (genreList.size()-1)*30;
		JLabel plotText = new JLabel("�ٰŸ�");
		plotText.setBounds(100, 580 + last_row, 100, 50);
		panel.add(plotText);
		
		JLabel showPlot = new JLabel(plot);
		showPlot.setBounds(250, 580 + last_row, 200, 50);
		panel.add(showPlot);
		
		
		
		add(panel);
		setSize(500, 800);																// ũ�� ����
		setVisible(true); 																// â�� ���̰� �ϱ�. �⺻�����δ� ������ ����
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	}
}
