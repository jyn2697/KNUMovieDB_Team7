import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class evaluateListView extends JFrame{
	private KNUMovie mv;
	
	public evaluateListView(int userPrivateID, int membershipNbr) {
		JPanel panel = new JPanel();							// panel�� �̿��� frame�� 
		panel.setLayout(null);									// ���ϴ� ��ġ�� ���ϴ� ������ �ִ´�
		
		// ����ڰ� �� ������ �� ��
		if(membershipNbr != 4) {
			try {
				mv.stmt = mv.conn.createStatement();	// DB�� ����
		        mv.conn.setAutoCommit(false); 			// auto-commit disabled
				String sql = "";
					
				sql = "SELECT M.TITLE, R.SCORE, R.COMMENTS "
					+ "FROM RATING R "
					+ "JOIN MOVIE M "
					+ "  ON M.ID = R.M_ID "
					+ "WHERE R.A_ID = " + userPrivateID;
		        
				mv.pstmt = mv.conn.prepareStatement(sql);
	            mv.rs = mv.pstmt.executeQuery();
	            
	            
	            int height = 0;
				while(mv.rs.next()) {
					System.out.println(mv.rs.getString(1));
					// ����ڰ� ���� ��ȭ �̸�
	            	JLabel movieTitle = new JLabel(mv.rs.getString(1));
	            	movieTitle.setBounds(50, 50 + height, 300, 50);
	                panel.add(movieTitle);
	                
	                // ����ڰ� ���� ����
	                JLabel movieScore = new JLabel(mv.rs.getString(2));
	                movieScore.setBounds(50, 80 + height, 50, 50);
	                panel.add(movieScore);
	                	                
	                // ������� comment
	                JLabel movieComment = new JLabel(mv.rs.getString(3));
	                movieComment.setBounds(150, 80 + height, 100, 50);
	                panel.add(movieComment);
	                
	                height += 100;
	            }	
			} catch (Exception e) {
				e.printStackTrace();
			}

		// �����ڰ� �� ������ �� ��
		} else {
			try {
				mv.stmt = mv.conn.createStatement();	// DB�� ����
		        mv.conn.setAutoCommit(false); 			// auto-commit disabled
				String sql = "";
					
				sql = "SELECT M.TITLE, R.SCORE, R.COMMENTS "
						+ "FROM RATING R "
						+ "JOIN MOVIE M "
						+ "  ON M.ID = R.M_ID";
		        
				mv.pstmt = mv.conn.prepareStatement(sql);
	            mv.rs = mv.pstmt.executeQuery();
	            
	            
	            int height = 0;
				while(mv.rs.next()) {
					System.out.println(mv.rs.getString(1));
					// ��ȭ �̸�
	            	JLabel movieTitle = new JLabel(mv.rs.getString(1));
	            	movieTitle.setBounds(50, 50 + height, 300, 50);
	                panel.add(movieTitle);
	                
	                // ���� ����
	                JLabel movieScore = new JLabel(mv.rs.getString(2));
	                movieScore.setBounds(50, 80 + height, 50, 50);
	                panel.add(movieScore);
	                	                
	                // comment
	                JLabel movieComment = new JLabel(mv.rs.getString(3));
	                movieComment.setBounds(150, 80 + height, 100, 50);
	                panel.add(movieComment);
	                
	                height += 100;
	            }
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		
		
		add(panel);
		setSize(500, 800);							// ũ�� ����
		setResizable(false); 						// ������ ������ ����
		setVisible(true); 							// â�� ���̰� �ϱ�. �⺻�����δ� ������ ����
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); 
	}
}
