import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class mainView extends JFrame {
	private KNUMovie mv;
	
	public mainView(int userPrivateID, int membershipNbr) {
		JPanel panel = new JPanel();							// panel�� �̿��� frame�� 
		panel.setLayout(null);									// ���ϴ� ��ġ�� ���ϴ� ������ �ִ´�
		
		try {
			mv.stmt = mv.conn.createStatement();	// DB�� ����
	        mv.conn.setAutoCommit(false); 			// auto-commit disabled
	        String sql = "";
	        
	        sql = "SELECT Title, ID FROM MOVIE ORDER BY ID";
	        
	        mv.pstmt = mv.conn.prepareStatement(sql);
            mv.rs = mv.pstmt.executeQuery();
            
            
            // �������� ��� ��ȭ�߰���ư
            if(membershipNbr == 4) {
            	JButton updateMovie = new JButton("����");
            	updateMovie.setBounds(50, 50, 70, 25);
            	updateMovie.addActionListener(new ActionListener() {
                	@Override
                	public void actionPerformed(ActionEvent e) {
                		new insertMovieView(userPrivateID, membershipNbr);
                		dispose();
                	}
                });
                panel.add(updateMovie);
            }
            
            // �˻� ��ư
            JButton search = new JButton("�˻�");
            search.setBounds(150, 50, 200, 25);
            panel.add(search);
            search.addActionListener(new ActionListener() {
            	@Override
            	public void actionPerformed(ActionEvent e) {
            		new searchView(userPrivateID);
            		dispose();
            	}
            });
                        
            
            // ȸ���������� ��ư
            JButton revise = new JButton("����");
            revise.setBounds(380, 50, 70, 25);
            revise.addActionListener(new ActionListener() {
            	@Override
            	public void actionPerformed(ActionEvent e) {
            		new reviseView(userPrivateID, membershipNbr);
            		dispose();
            	}
            });
            panel.add(revise);
            
    		
    		// �� ��ȭ�� ���� ��ư
			int next_box_row = 0;					// ��ȭ�� ����
			String movieList[] = new String[4];
			int count = 0;
            while(mv.rs.next()) {
            	// �⺻���� �����ִ� ��ȭ�� 4��
            	if(next_box_row == 600)
            		break;
            	
            	JButton movie = new JButton(mv.rs.getString(1));
	        	movie.setBounds(150, 100 + next_box_row, 200, 100);
	        	String movieTitle = mv.rs.getString(1);
	        	int movieID = Integer.parseInt(mv.rs.getString(2));
	        	movie.addActionListener(new ActionListener() {
	    			@Override
	    			public void actionPerformed(ActionEvent e) {
    					new detailView(userPrivateID, movieTitle, movieID);			// �ش� ��ȭ �󼼺���� �Ѿ
	    				dispose();
	    			}
	    		});
	        	next_box_row += 150;
	    		panel.add(movie);
            }
            
		} catch(Exception e) {
			e.printStackTrace();
		}
		
		// �򰡸�� Ȯ��
		JButton evaluateList = new JButton("�򰡸��");
		evaluateList.setBounds(50, 680, 200, 50);
        panel.add(evaluateList);
        evaluateList.addActionListener(new ActionListener() {
        	@Override
        	public void actionPerformed(ActionEvent e) {
        		new evaluateListView(userPrivateID, membershipNbr);
        		dispose();
        	}
        });
		
        
		
		add(panel);
		setSize(500, 800);							// ũ�� ����
		setResizable(false); 						// ������ ������ ����
		setVisible(true); 							// â�� ���̰� �ϱ�. �⺻�����δ� ������ ����
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); 
	}
}

