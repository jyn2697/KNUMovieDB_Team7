import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileInputStream;
import java.net.URL;

import javax.imageio.ImageIO;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

public class reviseView extends JFrame{
	private KNUMovie mv;
	int new_row = 0;
	int new_col = 0;
	String gender_sel = "";
	String membership_sel = "";
	int[] check_box = {0, 0, 0, 0, 0, 0, 0};
	JCheckBox[] checkbox = new JCheckBox[8];
	
	public reviseView(int userPrivateID, int membershipNbr) {
		JPanel panel = new JPanel();											// panel�� �̿��� frame�� 
		panel.setLayout(null);													// ���ϴ� ��ġ�� ���ϴ� ������ �ִ´�

		// ���̵�
		JLabel id = new JLabel("ID");
		id.setBounds(100, 100, 70, 30);
		panel.add(id);
		
		String user_id = "";
		try {
			mv.stmt = mv.conn.createStatement();	// DB�� ����
	        mv.conn.setAutoCommit(false); 			// auto-commit disabled 
	        String sql = "";
			
			sql = "SELECT Account_ID "
					+ "FROM MOVIE "
					+ "WHERE ID = " + userPrivateID;
								
			mv.pstmt = mv.conn.prepareStatement(sql);
            mv.rs = mv.pstmt.executeQuery();
            
            
            while(mv.rs.next()) {
            	user_id = mv.rs.getString(1);
            }
		} catch(Exception e) {
			
		}
		
		JLabel idText = new JLabel(user_id);
		idText.setBounds(200, 100, 100, 30);
		panel.add(idText);
		
		
		// ��й�ȣ
		JLabel pw = new JLabel("������ PW");
		pw.setBounds(100, 150, 70, 30);
		panel.add(pw);
		
		JTextField pwText = new JTextField();
		pwText.setBounds(200, 150, 100, 30);
		panel.add(pwText);
		
		// ��й�ȣ Ȯ��
		JLabel pwCheck = new JLabel("PW Ȯ��");
		pwCheck.setBounds(100, 200, 70, 30);
		panel.add(pwCheck);
		
		JTextField pwCheckText = new JTextField();
		pwCheckText.setBounds(200, 200, 100, 30);
		panel.add(pwCheckText);
		
		// �̸�
		JLabel name = new JLabel("�̸�");
		name.setBounds(100, 250, 70, 30);
		panel.add(name);
		
		JTextField nameText = new JTextField();
		nameText.setBounds(200, 250, 100, 30);
		panel.add(nameText);
			
		// ��ȭ��ȣ
		JLabel phoneNbr = new JLabel("��ȭ��ȣ");
		phoneNbr.setBounds(100, 300, 100, 30);
		panel.add(phoneNbr);
					
		JTextField phoneNbrText = new JTextField();
		phoneNbrText.setBounds(200, 300, 100, 30);
		panel.add(phoneNbrText);
		
		JLabel phoneNbrForm = new JLabel("(010-xxxx-xxxx)");
		phoneNbrForm.setBounds(350, 300, 100, 30);
		panel.add(phoneNbrForm);
		
		// ����
		JLabel gender = new JLabel("����");
		gender.setBounds(100, 350, 100, 30);
		panel.add(gender);
		
		ButtonGroup gender_gp = new ButtonGroup();
		
		JRadioButton man = new JRadioButton("����");
		man.setBounds(200, 350, 70, 30);
		man.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				gender_sel = "M";
			}
		});
		gender_gp.add(man);
		panel.add(man);	
		
		JRadioButton woman = new JRadioButton("����");
		woman.setBounds(270, 350, 70, 30);
		woman.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				gender_sel = "F";
			}
		});
		gender_gp.add(woman);
		panel.add(woman);
			
		// �ּ�
		JLabel address = new JLabel("�ּ�");
		address.setBounds(100, 400, 100, 30);
		panel.add(address);
					
		JTextField addressText = new JTextField();
		addressText.setBounds(200, 400, 100, 30);
		panel.add(addressText);
		
		// �������
		JLabel birthDate = new JLabel("�������");
		birthDate.setBounds(100, 450, 100, 30);
		panel.add(birthDate);
					
		JTextField birthDateText = new JTextField();
		birthDateText.setBounds(200, 450, 100, 30);
		panel.add(birthDateText);
		
		JLabel birthDateForm = new JLabel("(yy/mm/dd)");
		birthDateForm.setBounds(350, 450, 100, 30);
		panel.add(birthDateForm);
		
		// ����
		JLabel job = new JLabel("����");
		job.setBounds(100, 500, 100, 30);
		panel.add(job);
					
		JTextField jobText = new JTextField();
		jobText.setBounds(200, 500, 100, 30);
		panel.add(jobText);
		
		// �����
		JLabel membership = new JLabel("�����");
		membership.setBounds(100, 550, 100, 30);
		panel.add(membership);
		
		ButtonGroup membership_gp = new ButtonGroup();
		
		JRadioButton mem_free = new JRadioButton("Free");
		mem_free.setBounds(200, 550, 100, 30);
		mem_free.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				membership_sel = "1";
			}
		});
		membership_gp.add(mem_free);
		panel.add(mem_free);	
		
		JRadioButton mem_basic = new JRadioButton("Basic");
		mem_basic.setBounds(300, 550, 70, 30);
		mem_basic.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				membership_sel = "2";
			}
		});
		membership_gp.add(mem_basic);
		panel.add(mem_basic);
		
		JRadioButton mem_premium = new JRadioButton("Premium");
		mem_premium.setBounds(200, 600, 100, 30);
		mem_premium.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				membership_sel = "3";
			}
		});
		membership_gp.add(mem_premium);
		panel.add(mem_premium);
		
		JRadioButton mem_prime = new JRadioButton("Prime");
		mem_prime.setBounds(300, 600, 70, 30);
		mem_prime.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				membership_sel = "4";
			}
		});
		membership_gp.add(mem_prime);
		panel.add(mem_prime);
		
		// ��ҹ�ư
		JButton cancel = new JButton("���");
		cancel.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				new mainView(userPrivateID, membershipNbr);
				dispose();
			}
		});
		cancel.setBounds(250, 650, 100, 30);
		panel.add(cancel);
		
					
		// ���� ��ư
		JButton finish = new JButton("����");
		finish.setBounds(100, 650, 100, 30);
		panel.add(finish);
		
		JTextField reviseList[] = {pwText, nameText, phoneNbrText, addressText, birthDateText, jobText};
		String reviseDBList[] = {"Account_PW", "Name", "Phone", "Address", "Bdate", "Job"};
				
		finish.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
			        mv.stmt = mv.conn.createStatement();	// DB�� ����
			        mv.conn.setAutoCommit(false); 			// auto-commit disabled 
			        String sql = "";
					
					// ������ ������ ���� ����
					for(int i = 0; i < 6; i++) {
						// ������ �������� ���� update
						if(!(reviseList[i].getText().equals(""))) {
							sql = "UPDATE ACCOUNT SET " + reviseDBList[i] + " = '" + reviseList[i].getText() + "' "
								+ "WHERE ID = '" + userPrivateID + "'";
							
							int res = mv.stmt.executeUpdate(sql);
						}
					}
					
					
					// ���� ����� ������Ʈ
					if(!(gender_sel.equals(""))) {
						sql = "UPDATE ACCOUNT SET Gender = '" + gender_sel + "' "
							+ "WHERE ID = '" + userPrivateID + "'";

						int res = mv.stmt.executeUpdate(sql);
					}
					
					// ����� ����� ������Ʈ
					if(!(membership_sel.equals(""))) {
						sql = "UPDATE ACCOUNT SET Membership_ID = '" + membership_sel + "' "
							+ "WHERE ID = '" + userPrivateID + "'";
						
						int res = mv.stmt.executeUpdate(sql);
					}
					
					mv.conn.commit();
					
					// ���� �� mainView�� �̵�
					new mainView(userPrivateID, membershipNbr);
					dispose();
				} catch (Exception e1) {
					
					e1.printStackTrace();
				}

			}
		});
		
		
		// ȸ��Ż��
		JButton bye = new JButton("ȸ�� Ż��");
		bye.setBounds(100, 700, 250, 30);
		panel.add(bye);
		bye.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					mv.stmt = mv.conn.createStatement();	// DB�� ����
					mv.conn.setAutoCommit(false); 			// auto-commit disabled 
					String sql = "";
					
					sql = "DELETE FROM ACCOUNT WHERE ID = '" + userPrivateID + "'";
					
					int res = mv.stmt.executeUpdate(sql);
					mv.conn.commit();
					
					// Ż�� �� �α��� ȭ������
					new loginView();
					dispose();
				} catch(Exception e2) {
					e2.printStackTrace();
				}
			}
		});
		
			
		add(panel);
		setSize(500, 800);									// ũ�� ����
		setVisible(true); 									// â�� ���̰� �ϱ�. �⺻�����δ� ������ ����
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);  	// â ������ ���α׷� ����
	}
}
