import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

public class evaluationView extends JFrame{
	private KNUMovie mv;
	
	public evaluationView(int userPrivateID, String movieTitle, int movieID) {
		JPanel panel = new JPanel();
		panel.setLayout(null);
		
		// ��ȭ ����
		JLabel titleText = new JLabel(movieTitle);
		titleText.setBounds(100, 50, 150, 50);
		panel.add(titleText);
		
		// �� ����
		JLabel scoreText = new JLabel("����");
		scoreText.setBounds(100, 100, 100, 30);
		panel.add(scoreText);
		
		JTextField score = new JTextField();
		score.setBounds(250, 100, 100, 30);
		panel.add(score);
		
		JLabel explainScore = new JLabel("(1 ~ 10) in N");
		explainScore.setBounds(250, 130, 100, 30);
		panel.add(explainScore);
				
		// ���� ��
		JLabel commentText = new JLabel("��");
		commentText.setBounds(100, 180, 100, 30);
		panel.add(commentText);
		
		JTextField comment = new JTextField();
		comment.setBounds(250, 180, 100, 30);
		panel.add(comment);
		
		// �� ����ϱ�
		JButton regist = new JButton("���");
		regist.setBounds(250, 230, 100, 30);
		panel.add(regist);
		regist.addActionListener(new ActionListener() {
    		@Override
    		public void actionPerformed(ActionEvent e) {
    			try {
    				mv.stmt = mv.conn.createStatement();	// DB�� ����
    		        mv.conn.setAutoCommit(false); 			// auto-commit disabled 
    		        String sql = "";
    				    		        
    		    	sql = "SELECT COUNT(*) FROM RATING";
    		        
    		    	mv.pstmt = mv.conn.prepareStatement(sql);
    	            mv.rs = mv.pstmt.executeQuery();
    	            
    	            // ���� ��ϵ� �� ����
    	            int ratingNbr = 0;
    	            while(mv.rs.next())
    	            	ratingNbr = Integer.parseInt(mv.rs.getString(1));
    	            
    	            
    	             sql = "INSERT INTO RATING VALUES ("
    	            		 		+ (ratingNbr+1) + ", " + score.getText()  + ", '" +  comment.getText()  + "', " 
    	            		 		+  userPrivateID  + ", " +  movieID + ")";
    	             System.out.println(sql);
    	             mv.pstmt = mv.conn.prepareStatement(sql);
     	             mv.rs = mv.pstmt.executeQuery();
			         mv.conn.commit();
			        
     	             JOptionPane.showMessageDialog(null, "��ϵǾ����ϴ�.");
    			} catch(Exception e2) {
    				e2.printStackTrace();
    			}
    			
    			dispose();				// �� �� â ����
    		}
    	});
		
		
		add(panel);
		
		setSize(500, 400);
		setVisible(true); 										// â�� ���̰� �ϱ�. �⺻�����δ� ������ ����
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);  	// â ������ �ش�ȭ�� ����
	}
}
