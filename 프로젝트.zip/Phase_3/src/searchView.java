import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileInputStream;
import java.net.URL;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JComboBox;


public class searchView extends JFrame{
	private KNUMovie mv;
	
	public searchView(int userPrivateID) {
		JPanel panel = new JPanel();
		panel.setLayout(null);

		
		// �������� �˻�
		JLabel searchCond1 = new JLabel("�������� �˻��ϱ�");
		searchCond1.setBounds(70, 50, 200, 30);
		panel.add(searchCond1);
		
		JTextField searchByTitle = new JTextField();
		searchByTitle.setBounds(70, 80, 200, 30);
		panel.add(searchByTitle);
		
		// �˻���ư
		JButton search1 = new JButton("�˻�");
		search1.setBounds(300, 80, 100, 30);
		panel.add(search1);
		search1.addActionListener(new ActionListener() {								
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					mv.stmt = mv.conn.createStatement();	// DB�� ����
			        mv.conn.setAutoCommit(false); 			// auto-commit disabled 
			        String sql = "";
					
					sql = "(SELECT TITLE, ID "
							+ "FROM MOVIE "
							+ "WHERE TITLE = '" 
							+ searchByTitle.getText() + "')"
							+ "MINUS "
							+ "(SELECT M.TITLE, M.ID "
							+ "FROM MOVIE M "
							+ "JOIN RATING R "
							+ "ON R.M_ID = M.ID "
							+ "WHERE R.A_ID = " + userPrivateID + ")";
					
					mv.pstmt = mv.conn.prepareStatement(sql);
		            mv.rs = mv.pstmt.executeQuery();
		            
		            int check = 0;
		            while(mv.rs.next()) {
		            	if(searchByTitle.getText().equals(mv.rs.getString(1))) {
		            		check = 1;
		            		new listView(userPrivateID, sql);
		            		dispose();
		            	}           
		            }
		            
		            if(check == 0) 
	            		JOptionPane.showMessageDialog(null, "�ش� ��ȭ�� �����ϴ�.");
		            
				} catch(Exception e1) {
					e1.printStackTrace();
				}
				
			}
		});

		
		// �������� �˼��ϱ�
		JLabel searchCond2 = new JLabel("�������� �˻��ϱ�");
		searchCond2.setBounds(70, 150, 200, 30);
		panel.add(searchCond2);
		
		String type[] = {"None", "Movie", "TV Series", "KnuMovieDB Original"};
		int typeNbr[] = {0, 1, 2, 3};
		String genre[] = {"None", "Action", "Thriller", "Adventure", "Romance", "Fantasy", "Comedy", "Drama"};
		int genreNbr[] = {0, 1, 2, 3, 4, 5, 6, 7};
		String version[] = {"None", "US", "KR", "ES", "AE", "VN", "IT", "JP"};
		int versionNbr[] = {0, 1, 2, 3, 4, 5, 6, 7};
		
		// Ÿ�� ����
		JLabel typeSelect = new JLabel("Type");
		typeSelect.setBounds(70, 180, 200, 30);
		panel.add(typeSelect);
		
		JComboBox typeCombo = new JComboBox(type);
		typeCombo.setBounds(70, 210, 200, 30);
		panel.add(typeCombo);
		
		// �帣 ����
		JLabel genreSelect = new JLabel("Genre");
		genreSelect.setBounds(70, 240, 200, 30);
		panel.add(genreSelect);
		
		JComboBox genreCombo = new JComboBox(genre);
		genreCombo.setBounds(70, 270, 200, 30);
		panel.add(genreCombo);
		
		// ���� ����
		JLabel versionSelect = new JLabel("Version");
		versionSelect.setBounds(70, 300, 200, 30);
		panel.add(versionSelect);
		
		JComboBox versionCombo = new JComboBox(version);
		versionCombo.setBounds(70, 330, 200, 30);
		panel.add(versionCombo);
		
		// �˻���ư
		JButton search2 = new JButton("�˻�");
		search2.setBounds(300, 330, 100, 30);
		panel.add(search2);
		search2.addActionListener(new ActionListener() {								
			@Override
			public void actionPerformed(ActionEvent e) {
				try {			
					mv.stmt = mv.conn.createStatement();	// DB�� ����
			        mv.conn.setAutoCommit(false); 			// auto-commit disabled 
			        String sql = "";
					
			        
			        int check = 0;							// where�� �ڿ� ������ �پ
			        										// ���� �߰����� AND �ؾ��� �� check = 1
			        sql = "(SELECT distinct m.TITLE, m.ID "
							+ "FROM MOVIE m, GENRE_TYPE gt, VERSION v ";
			        
			        if(!(typeCombo.getSelectedItem().toString().equals("None"))) {
			        	check = 1;
			        	for(int i = 0; i < 4; i++) {
			        		if(typeCombo.getSelectedItem().toString().equals(type[i])) {
			        			sql = sql + "WHERE m.Type_ID = " + i;
			        			break;
			        		}
			        	}
			        }
			        	
			        if(!(genreCombo.getSelectedItem().toString().equals("None"))) {
			        	for(int i = 0; i < 8; i++) {
			        		if(genreCombo.getSelectedItem().toString().equals(genre[i])) {
			        			if(check == 0) 
			        				sql = sql + "WHERE ";
			        			else 
			        				sql = sql + " AND ";
			        			
			        			sql = sql + "gt.G_ID = " + i
		        						  + " AND gt.M_ID = m.ID";
			        		}
			        	}
			        }
			        
			        if(!(versionCombo.getSelectedItem().toString().equals("None"))) {
			        	for(int i = 0; i < 8; i++) {
			        		if(versionCombo.getSelectedItem().toString().equals(version[i])) {
			        			if(check == 0) 
			        				sql = sql + "WHERE ";
			        			else 
			        				sql = sql + " AND ";
			        			
			        			sql = sql + "v.IS_ORIGINAL_TITLE = " + i
		        						  + " AND v.M_ID = m.ID";
			        		}
			        	}
			        }
			        
			        sql = sql + ") MINUS "
			        		+"(SELECT M.TITLE, M.ID "
			        		+ "FROM MOVIE M "
			        		+ "JOIN RATING R "
			        		+ "ON R.M_ID = M.ID "
			        		+ "WHERE R.A_ID = " + userPrivateID + ")";
			        
					new listView(userPrivateID, sql);
					dispose();
				} catch(Exception e1) {
					e1.printStackTrace();
				}
				
			}
		});
		
		
		add(panel);
		
		setSize(500, 500);															// ũ�� ����
		setVisible(true); 															// â�� ���̰� �ϱ�. �⺻�����δ� ������ ����
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);  						// â ������ ���α׷� ����
	}
}
