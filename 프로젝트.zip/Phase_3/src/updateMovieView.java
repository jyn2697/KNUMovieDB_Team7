import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.io.FileInputStream;
import java.net.URL;

import javax.imageio.ImageIO;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

public class updateMovieView extends JFrame{
	private KNUMovie mv;
	String type_sel = "";
	int[] type_box = {0, 0, 0};
	JCheckBox[] type_checkbox = new JCheckBox[3];
	int[] genre_box = {0, 0, 0, 0, 0, 0, 0};
	JCheckBox[] genre_checkbox = new JCheckBox[7];
	
	public updateMovieView(int userPrivateID, String movieTitle, int movieID) {
		JPanel panel = new JPanel();							// panel�� �̿��� frame�� 
		panel.setLayout(null);									// ���ϴ� ��ġ�� ���ϴ� ������ �ִ´�
		
		// ����
		JLabel title = new JLabel("����");
		title.setBounds(80, 50, 70, 30);
		panel.add(title);
				
		JLabel titleText = new JLabel(movieTitle);
		titleText.setBounds(180, 50, 100, 30);
		panel.add(titleText);
		
		
		// �ٰŸ�
		JLabel plot = new JLabel("�ٰŸ�");
		plot.setBounds(80, 100, 70, 30);
		panel.add(plot);
		
		JTextField plotText = new JTextField();
		plotText.setBounds(180, 100, 100, 30);
		panel.add(plotText);
		
		
		// �� �ð�
		JLabel runningTime = new JLabel("�� �ð�(��)");
		runningTime.setBounds(80, 150, 70, 30);
		panel.add(runningTime);
		
		JTextField runningTimeText = new JTextField();
		runningTimeText.setBounds(180, 150, 100, 30);
		panel.add(runningTimeText);
		
		
		// ������
		JLabel releasedDate = new JLabel("���� ��¥");
		releasedDate.setBounds(80, 200, 70, 30);
		panel.add(releasedDate);
		
		JTextField releasedDateText = new JTextField();
		releasedDateText.setBounds(180, 200, 100, 30);
		panel.add(releasedDateText);
		
		JLabel format = new JLabel("(yyyy/mm/dd)");
		format.setBounds(300, 200, 100, 30);
		panel.add(format);
		
		
		// ���� Ÿ��
		JLabel type = new JLabel("���� ����");
		type.setBounds(80, 250, 100, 30);
		panel.add(type);
		
		ButtonGroup type_gp = new ButtonGroup();
		String typeList[] = {"Movie", "TV Series", "KnuMovieDB Original"};
		int row = 0;
		int col = 0;
		for(int i = 0; i < 3; i ++) {
			if(i != 0 && i % 2 == 0) {
				row = 0;
				col += 50;
			}
			
			JRadioButton typeName = new JRadioButton(typeList[i]);
			if(i == 2)
				typeName.setBounds(180 + row, 250 + col, 200, 30);
			else
				typeName.setBounds(180 + row, 250 + col, 100, 30);
			
			String tmp = typeList[i];
			typeName.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					type_sel = tmp;
				}
			});
			
			type_gp.add(typeName);
			panel.add(typeName);
			
			row += 100;
		}
		
		
		// �帣
		JLabel genre = new JLabel("���� ����");
		genre.setBounds(80, 350, 100, 30);
		panel.add(genre);
		
		String genreList[] = {"Action", "Thriller", "Adventure", "Romance", "Fantasy", "Comedy", "Drama"};
		row = 0;
		col = 0;
		for(int i = 0; i < 7; i ++) {
			if(i != 0 && i % 3 == 0) {
				row = 0;
				col += 50;
			}
			
			genre_checkbox[i] = new JCheckBox(genreList[i]);
			genre_checkbox[i].addItemListener(new MyItemListener());
			genre_checkbox[i].setBounds(180 + row, 350 + col, 100, 30);
			panel.add(genre_checkbox[i]);
			
			row += 100;
		}

		
		// ���ۻ�
		String productionList[] = {"None", "CG CGV", "JK Films", "HB Entertainment", "GwangHwa cinema", 
				"Next Entertainment World", "Daewon Midea", "Baram Pictures", "Barensom EA", 
				"Tube Entertainment", "Dreamworks", "Marvel Studios", "Walt Disney Studios", 
				"Pamamount pictures", "T-Series", "Soni Pictures Entertainment", "Nordisk Film", 
				"BBC Films", "Alibaba Pictures", "StudioCanal", "KNUMovie"};
		int productionListNbr[] = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20};
		
		JLabel productionName = new JLabel("���ۻ�");
		productionName.setBounds(80, 500, 100, 30);
		panel.add(productionName);
					
		JComboBox production = new JComboBox(productionList);
		production.setBounds(180, 500, 100, 30);
		panel.add(production);
		
		
		// ��޻�
		String distributionList[] = {"None", "Lotte Entertainment", "NEW", "Show Box", "Walt Disney", 
				"Wanner Brothers", "Sony Pictures", "Universial Pictures", "Paramount Pictures", 
				"Toei Animation", "Huaxia Film", "Sonamu Pictures", "D Station", "Big Film", "STX Entertainment", 
				"Amazon Studio", "Annapurna", "Hannover-House", "Hasbro Studio", "CBS Films", "KNUMovie"};
		int distributionListNbr[] = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20};
		
		JLabel distributionName = new JLabel("��޻�");
		distributionName.setBounds(80, 550, 100, 30);
		panel.add(distributionName);
		
		JComboBox distribution = new JComboBox(distributionList);
		distribution.setBounds(180, 550, 100, 30);
		panel.add(distribution);
			
		// ���
		JLabel actor = new JLabel("���");
		actor.setBounds(80, 600, 100, 30);
		panel.add(actor);
					
		JTextField actorText1 = new JTextField();
		actorText1.setBounds(180, 600, 100, 30);
		panel.add(actorText1);
		
		JTextField actorText2 = new JTextField();
		actorText2.setBounds(300, 600, 100, 30);
		panel.add(actorText2);
		
		// ����
		JLabel director = new JLabel("����");
		director.setBounds(80, 650, 100, 30);
		panel.add(director);
					
		JTextField directorText = new JTextField();
		directorText.setBounds(180, 650, 100, 30);
		panel.add(directorText);
				
		// �۰�
		JLabel writer = new JLabel("�۰�");
		writer.setBounds(80, 700, 100, 30);
		panel.add(writer);
					
		JTextField writerText = new JTextField();
		writerText.setBounds(180, 700, 100, 30);
		panel.add(writerText);
		
					
		// ��� ��ư
		JButton finish = new JButton("���");
		finish.setBounds(100, 750, 300, 30);
		panel.add(finish);
		finish.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					mv.stmt = mv.conn.createStatement();	// DB�� ����
			        mv.conn.setAutoCommit(false); 			// auto-commit disabled 
			        String sql = "";
			        
		            // movie table���� ����
		            // ������ �ٰŸ��� �������� ����
					if(!(plotText.getText().equals(""))) {
			        	sql = "UPDATE MOVIE SET PLOT = '" + plotText.getText() + "' WHERE ID = " + movieID;
			        	mv.pstmt = mv.conn.prepareStatement(sql);
			            mv.rs = mv.pstmt.executeQuery();
			        }
					
					// ������ �󿵽ð��� �������� ����
					if(!(runningTimeText.getText().equals(""))) {
						sql = "UPDATE MOVIE SET RUNNING_TIME = " + runningTimeText.getText() + " WHERE ID = " + movieID;
			        	mv.pstmt = mv.conn.prepareStatement(sql);
			            mv.rs = mv.pstmt.executeQuery();
					}
					
			        // ������ �������� �������� ����
					if(!(releasedDateText.getText().equals(""))) {
						sql = "UPDATE MOVIE SET RELEASED_DATE = '" + releasedDateText.getText() + "' WHERE ID = " + movieID;
			        	mv.pstmt = mv.conn.prepareStatement(sql);
			            mv.rs = mv.pstmt.executeQuery();
					}
	            
					// ������ ���� ������ �������� ����
					if(!(releasedDateText.getText().equals(""))) {
						int typeNbr = 0;
			            for(int i = 0; i < 3; i ++)
			            	if(type_sel.equals(typeList[i]))
			            		typeNbr = i+1;
			            
						sql = "UPDATE MOVIE SET TYPE_ID = " + typeNbr + " WHERE ID = " + movieID;
			        	mv.pstmt = mv.conn.prepareStatement(sql);
			            mv.rs = mv.pstmt.executeQuery();
					}
					
		            
					// making table�� ����
					if(!(production.getSelectedItem().toString().equals("None"))) {
						int productionNbr = 0;
			            for(int i = 0; i < 21; i ++)
			            	if(production.getSelectedItem().toString().equals(productionList[i]))
			            		productionNbr = i+1;
			            
						sql = "UPDATE MAKING SET P_ID = " + productionNbr + " WHERE M_ID = " + movieID;
			        	mv.pstmt = mv.conn.prepareStatement(sql);
			            mv.rs = mv.pstmt.executeQuery();
					}
		            
					
					// distributing table�� ����
					if(!(distribution.getSelectedItem().toString().equals("None"))) {
						int distributionNbr = 0;
			            for(int i = 0; i < 21; i ++)
			            	if(production.getSelectedItem().toString().equals(distributionList[i]))
			            		distributionNbr = i+1;
			            
						sql = "UPDATE MAKING SET P_ID = " + distributionNbr + " WHERE M_ID = " + movieID;
			        	mv.pstmt = mv.conn.prepareStatement(sql);
			            mv.rs = mv.pstmt.executeQuery();
					}
					
					
					// genre table�� ����
					// Ư�� �帣�� �����ϱ� ����� ������
					// ���� �����ϰ�, ������ �帣�� �߰�
					int check_genre = 0;
					for(int i = 0; i < 7; i++) {
						if(genre_box[i] == 1) {
							check_genre = 1;
							break;
						}
					}
					
					if(check_genre == 1) {
						sql = "DELETE FROM GENRE_TYPE WHERE M_ID = " + movieID;
						mv.pstmt = mv.conn.prepareStatement(sql);
						mv.rs = mv.pstmt.executeQuery();
						
						for(int i = 0; i < 7; i++) {
			            	if(genre_box[i] == 1) {
			            		sql = "INSERT INTO GENRE_TYPE VALUES ('" + movieID + "', " + (i+1) + ")";
					            System.out.println(sql);
						        mv.pstmt = mv.conn.prepareStatement(sql);
					            mv.rs = mv.pstmt.executeQuery();
			            	}
			            }
					}
					
					
					// actor table�� ����
					// Ư�� ��츸 �����ϱ� ����� ������
					// ���� �����ϰ�, ������ ���� �߰�
					if(!(actorText1.getText().equals(""))) {
						sql = "DELETE FROM CASTING_LIST WHERE M_ID = " + movieID;
						mv.pstmt = mv.conn.prepareStatement(sql);
			            mv.rs = mv.pstmt.executeQuery();
						
			            // ��ϵ� ������� Ȯ��
			            sql = "SELECT COUNT(*) FROM ACTOR WHERE NAME = '" + actorText1.getText() + "'";
			            
			            System.out.println(sql);
				        mv.pstmt = mv.conn.prepareStatement(sql);
			            mv.rs = mv.pstmt.executeQuery();
			            
			            int checkCount = 0;
			            while(mv.rs.next())
			            	 checkCount = Integer.parseInt(mv.rs.getString(1));
			            
			            // ��찡 ������ ��
			            if(checkCount == 1) {
			            	sql = "SELECT ID FROM ACTOR WHERE NAME = '" + actorText1.getText() + "'";
			            	
			            	System.out.println(sql);
					        mv.pstmt = mv.conn.prepareStatement(sql);
				            mv.rs = mv.pstmt.executeQuery();
				            
				            
				            int actorID = 0;
				            while(mv.rs.next())
				            	 actorID = Integer.parseInt(mv.rs.getString(1));
				            
				            sql = "INSERT INTO CASTING_LIST VALUES (" + movieID + ", "+ actorID + ", 'L')";
				            		
				            System.out.println(sql);
					        mv.pstmt = mv.conn.prepareStatement(sql);
				            mv.rs = mv.pstmt.executeQuery();
			            }
			            // ��찡 �������� ���� ��
			            else {
			            	// ����� ���� Ȯ���Ͽ� ���� ��ȣ�� �ֱ�
			            	sql = "SELECT COUNT(*) FROM ACTOR";
			            	mv.pstmt = mv.conn.prepareStatement(sql);
				            mv.rs = mv.pstmt.executeQuery();
				            
				            int actorAmount = 0;
				            while(mv.rs.next())
				            	actorAmount = Integer.parseInt(mv.rs.getString(1)) + 1;
				            
				            // actor table�� ��� ���� �Է�
			            	sql = "INSERT INTO ACTOR VALUES (" + actorAmount + ", '"+ actorText1.getText() + "', 'M')";
			            	mv.pstmt = mv.conn.prepareStatement(sql);
				            mv.rs = mv.pstmt.executeQuery();
			            	
				            // casting_list�� ���� �Է�
				            sql = "INSERT INTO CASTING_LIST VALUES (" + movieID + ", "+ actorAmount+1 + ", 'L')";
			            }
					}
					
					if(!(actorText2.getText().equals(""))) {
						// ��ϵ� ������� Ȯ��
			            sql = "SELECT COUNT(*) FROM ACTOR WHERE NAME = '" + actorText2.getText() + "'";
			            
			            System.out.println(sql);
				        mv.pstmt = mv.conn.prepareStatement(sql);
			            mv.rs = mv.pstmt.executeQuery();
			            
			            int checkCount = 0;
			            while(mv.rs.next())
			            	 checkCount = Integer.parseInt(mv.rs.getString(1));
			            
			            // ��찡 ������ ��
			            if(checkCount == 1) {
			            	sql = "SELECT ID FROM ACTOR WHERE NAME = '" + actorText2.getText() + "'";
			            	
			            	System.out.println(sql);
					        mv.pstmt = mv.conn.prepareStatement(sql);
				            mv.rs = mv.pstmt.executeQuery();
				            
				            
				            int actorID = 0;
				            while(mv.rs.next())
				            	 actorID = Integer.parseInt(mv.rs.getString(1));
				            
				            sql = "INSERT INTO CASTING_LIST VALUES (" + movieID + ", "+ actorID + ", 'L')";
				            		
				            System.out.println(sql);
					        mv.pstmt = mv.conn.prepareStatement(sql);
				            mv.rs = mv.pstmt.executeQuery();
			            }
			            // ��찡 �������� ���� ��
			            else {
			            	// ����� ���� Ȯ���Ͽ� ���� ��ȣ�� �ֱ�
			            	sql = "SELECT COUNT(*) FROM ACTOR";
			            	mv.pstmt = mv.conn.prepareStatement(sql);
				            mv.rs = mv.pstmt.executeQuery();
				            
				            int actorAmount = 0;
				            while(mv.rs.next())
				            	actorAmount = Integer.parseInt(mv.rs.getString(1)) + 1;
			            	
				            // actor table�� ��� ���� �Է�
			            	sql = "INSERT INTO ACTOR VALUES (" + actorAmount + ", '"+ actorText2.getText() + "', 'M')";
			            	System.out.println(sql);
			            	mv.pstmt = mv.conn.prepareStatement(sql);
				            mv.rs = mv.pstmt.executeQuery();
			            	
				            // casting_list�� ���� �Է�
				            sql = "INSERT INTO CASTING_LIST VALUES (" + movieID + ", "+ actorAmount + ", 'L')";
				            System.out.println(sql);
			            }
					}
			        
		            
					// writer table�� ����
					// Ư�� �۰��� �����ϱ� ����� ������
					// ���� �����ϰ�, ������ �۰��� �߰�
					if(!(directorText.getText().equals(""))) {
						sql = "DELETE FROM CREW_OF_WRITER WHERE M_ID = " + movieID;
						mv.pstmt = mv.conn.prepareStatement(sql);
			            mv.rs = mv.pstmt.executeQuery();
			            
			            sql = "SELECT COUNT(*) FROM WRITER WHERE NAME = '" + writerText.getText() + "'";
			            
			            System.out.println(sql);
				        mv.pstmt = mv.conn.prepareStatement(sql);
			            mv.rs = mv.pstmt.executeQuery();
			            
			            int checkCount = 0;
			            while(mv.rs.next())
			            	 checkCount = Integer.parseInt(mv.rs.getString(1));
			            
			            // ��찡 ������ ��
			            if(checkCount == 1) {
			            	sql = "SELECT ID FROM WRITER WHERE NAME = '" + writerText.getText() + "'";
			            	
			            	System.out.println(sql);
					        mv.pstmt = mv.conn.prepareStatement(sql);
				            mv.rs = mv.pstmt.executeQuery();
				            
				            
				            int writerID = 0;
				            while(mv.rs.next())
				            	writerID = Integer.parseInt(mv.rs.getString(1));
				            
				            sql = "INSERT INTO CREW_OF_WRITER VALUES (" + movieID + ", "+ writerID + ")";
				            		
				            System.out.println(sql);
					        mv.pstmt = mv.conn.prepareStatement(sql);
				            mv.rs = mv.pstmt.executeQuery();
			            }
			            // ��찡 �������� ���� ��
			            else {
			            	// ����� ���� Ȯ���Ͽ� ���� ��ȣ�� �ֱ�
			            	sql = "SELECT COUNT(*) FROM WRITER";
			            	mv.pstmt = mv.conn.prepareStatement(sql);
				            mv.rs = mv.pstmt.executeQuery();
				            
				            int writerAmount = 0;
				            while(mv.rs.next())
				            	writerAmount = Integer.parseInt(mv.rs.getString(1)) + 1;
			            	
				            // actor table�� ��� ���� �Է�
			            	sql = "INSERT INTO WRITER VALUES (" + writerAmount + ", '"+ writerText.getText() + "')";
			            	mv.pstmt = mv.conn.prepareStatement(sql);
				            mv.rs = mv.pstmt.executeQuery();
			            	
				            // casting_list�� ���� �Է�
				            sql = "INSERT INTO CREW_OF_WRITER VALUES (" + movieID + ", "+ writerAmount + ")";
			            }
					}
		            
		            
		            if((!writerText.getText().equals(""))) {
		            	// director table�� ����
			            // Ư�� ������ �����ϱ� ����� ������
						// ���� �����ϰ�, ������ ������ �߰�
			            sql = "DELETE FROM CREW_OF_DIRECTOR WHERE M_ID = " + movieID;
						mv.pstmt = mv.conn.prepareStatement(sql);
			            mv.rs = mv.pstmt.executeQuery();
			            
			            sql = "SELECT COUNT(*) FROM DIRECTOR WHERE NAME = '" + directorText.getText() + "'";
			            
			            System.out.println(sql);
				        mv.pstmt = mv.conn.prepareStatement(sql);
			            mv.rs = mv.pstmt.executeQuery();
			            
			            int checkCount = 0;
			            while(mv.rs.next())
			            	 checkCount = Integer.parseInt(mv.rs.getString(1));
			            
			            // ��찡 ������ ��
			            if(checkCount == 1) {
			            	sql = "SELECT ID FROM DIRECTOR WHERE NAME = '" + directorText.getText() + "'";
			            	
			            	System.out.println(sql);
					        mv.pstmt = mv.conn.prepareStatement(sql);
				            mv.rs = mv.pstmt.executeQuery();
				            
				            
				            int directorID = 0;
				            while(mv.rs.next())
				            	directorID = Integer.parseInt(mv.rs.getString(1));
				            
				            sql = "INSERT INTO CREW_OF_DIRECTOR VALUES (" + movieID + ", "+ directorID + ")";
				            		
				            System.out.println(sql);
					        mv.pstmt = mv.conn.prepareStatement(sql);
				            mv.rs = mv.pstmt.executeQuery();
			            }
			            // ��찡 �������� ���� ��
			            else {
			            	// ����� ���� Ȯ���Ͽ� ���� ��ȣ�� �ֱ�
			            	sql = "SELECT COUNT(*) FROM DIRECTOR";
			            	mv.pstmt = mv.conn.prepareStatement(sql);
				            mv.rs = mv.pstmt.executeQuery();
				            
				            int directorAmount = 0;
				            while(mv.rs.next())
				            	directorAmount = Integer.parseInt(mv.rs.getString(1)) + 1;
			            	
				            // actor table�� ��� ���� �Է�
			            	sql = "INSERT INTO DIRECTOR VALUES (" + directorAmount + ", '"+ directorText.getText() + "')";
			            	mv.pstmt = mv.conn.prepareStatement(sql);
				            mv.rs = mv.pstmt.executeQuery();
			            	
				            // casting_list�� ���� �Է�
				            sql = "INSERT INTO CREW_OF_DIRECTOR VALUES (" + movieID + ", "+ directorAmount + ")";
			            }
		            }
		            
		            
		            mv.conn.commit();
					new detailView(userPrivateID, movieTitle, movieID);
					dispose();
				} catch (Exception e1) {
					e1.printStackTrace();
				}

			}
		});
		
		
		add(panel);
		setSize(500, 850);							// ũ�� ����
		setResizable(false); 						// ������ ������ ����
		setVisible(true); 							// â�� ���̰� �ϱ�. �⺻�����δ� ������ ����
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); 
	}
	
	class MyItemListener implements ItemListener {
		@Override
		public void itemStateChanged(ItemEvent e) {
			int select = 0;
			
			if(e.getStateChange() == ItemEvent.SELECTED)
				select = 1;
			else
				select = 0;
			
			for(int i = 0; i < 7; i ++) {
				if(e.getItem() == genre_checkbox[i]) {
					genre_box[i] = select;				
					break;
				}
			}
		}
	}
}

