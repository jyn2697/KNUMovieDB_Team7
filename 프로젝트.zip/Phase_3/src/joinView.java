import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

import java.sql.*;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class joinView extends JFrame {
	private KNUMovie mv;
	String gender_sel = "";
	String membership_sel = "";
	
	public joinView() {
		JPanel panel = new JPanel();															// panel�� �̿��� frame�� 
		panel.setLayout(null);																	// ���ϴ� ��ġ�� ���ϴ� ������ �ִ´�

		// ���̵�
		JLabel id = new JLabel("ID*");
		id.setBounds(100, 50, 70, 30);
		panel.add(id);
				
		JTextField idText = new JTextField();
		idText.setBounds(200, 50, 100, 30);
		panel.add(idText);
		
		// ���̵� �ߺ�Ȯ��
		JButton idCheck = new JButton("�ߺ�Ȯ��");
		idCheck.setBounds(350, 50, 100, 30);
		panel.add(idCheck);
		add(panel);
		idCheck.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
			        mv.stmt = mv.conn.createStatement();	// DB�� ����
			        mv.conn.setAutoCommit(false); 			// auto-commit disabled 
			        String sql = "";
					int check = 0;
			        
			    	sql = "SELECT Account_ID FROM ACCOUNT WHERE Account_ID = '" + idText.getText() + "'";
			        mv.pstmt = mv.conn.prepareStatement(sql);
		            mv.rs = mv.pstmt.executeQuery();
		            
		            while(mv.rs.next()) {
		            	if(idText.getText().equals(mv.rs.getString(1))) {
		            		JOptionPane.showMessageDialog(null, "�ߺ��� ���̵��Դϴ�.");
		            		check = 1;
		            	}
		            }
		            
		            if(check == 0)
		            	JOptionPane.showMessageDialog(null, "��� ������ ���̵��Դϴ�.");
				} catch(Exception e2) {
					e2.printStackTrace();
				}
			}
		});
		
		
		// ��й�ȣ
		JLabel pw = new JLabel("PW*");
		pw.setBounds(100, 100, 70, 30);
		panel.add(pw);
		
		JTextField pwText = new JTextField();
		pwText.setBounds(200, 100, 100, 30);
		panel.add(pwText);
		
		// ��й�ȣ Ȯ��
		JLabel pwCheck = new JLabel("PW Ȯ��*");
		pwCheck.setBounds(100, 150, 70, 30);
		panel.add(pwCheck);
		
		JTextField pwCheckText = new JTextField();
		pwCheckText.setBounds(200, 150, 100, 30);
		panel.add(pwCheckText);
		
		// �̸�
		JLabel name = new JLabel("�̸�*");
		name.setBounds(100, 200, 70, 30);
		panel.add(name);
		
		JTextField nameText = new JTextField();
		nameText.setBounds(200, 200, 100, 30);
		panel.add(nameText);
			
		// ��ȭ��ȣ
		JLabel phoneNbr = new JLabel("��ȭ��ȣ*");
		phoneNbr.setBounds(100, 250, 100, 30);
		panel.add(phoneNbr);
					
		JTextField phoneNbrText = new JTextField();
		phoneNbrText.setBounds(200, 250, 100, 30);
		panel.add(phoneNbrText);
		
		JLabel phoneNbrForm = new JLabel("(010-xxxx-xxxx)");
		phoneNbrForm.setBounds(350, 250, 100, 30);
		panel.add(phoneNbrForm);
		
		// ����
		JLabel gender = new JLabel("����");
		gender.setBounds(100, 300, 100, 30);
		panel.add(gender);
		
		ButtonGroup gender_gp = new ButtonGroup();
		
		JRadioButton man = new JRadioButton("����");
		man.setBounds(200, 300, 70, 30);
		man.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				gender_sel = "M";
			}
		});
		gender_gp.add(man);
		panel.add(man);
		
		JRadioButton woman = new JRadioButton("����");
		woman.setBounds(270, 300, 70, 30);
		woman.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				gender_sel = "F";
			}
		});
		gender_gp.add(woman);
		panel.add(woman);
			
		// �ּ�
		JLabel address = new JLabel("�ּ�");
		address.setBounds(100, 350, 100, 30);
		panel.add(address);
					
		JTextField addressText = new JTextField();
		addressText.setBounds(200, 350, 100, 30);
		panel.add(addressText);
		
		// �������
		JLabel birthDate = new JLabel("�������");
		birthDate.setBounds(100, 400, 100, 30);
		panel.add(birthDate);
					
		JTextField birthDateText = new JTextField();
		birthDateText.setBounds(200, 400, 100, 30);
		panel.add(birthDateText);
		
		JLabel birthDateForm = new JLabel("(yy/mm/dd)");
		birthDateForm.setBounds(350, 400, 100, 30);
		panel.add(birthDateForm);
		
		// ����
		JLabel job = new JLabel("����");
		job.setBounds(100, 450, 100, 30);
		panel.add(job);
					
		JTextField jobText = new JTextField();
		jobText.setBounds(200, 450, 100, 30);
		panel.add(jobText);
		
		// �����
		JLabel membership = new JLabel("�����");
		membership.setBounds(100, 500, 100, 30);
		panel.add(membership);
		
		ButtonGroup membership_gp = new ButtonGroup();
		
		JRadioButton mem_free = new JRadioButton("Free");
		mem_free.setBounds(200, 500, 100, 30);
		mem_free.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				membership_sel = "1";
			}
		});
		membership_gp.add(mem_free);
		panel.add(mem_free);	
		
		JRadioButton mem_basic = new JRadioButton("Basic");
		mem_basic.setBounds(300, 500, 70, 30);
		mem_basic.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				membership_sel = "2";
			}
		});
		membership_gp.add(mem_basic);
		panel.add(mem_basic);
		
		JRadioButton mem_premium = new JRadioButton("Premium");
		mem_premium.setBounds(200, 550, 100, 30);
		mem_premium.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				membership_sel = "3";
			}
		});
		membership_gp.add(mem_premium);
		panel.add(mem_premium);
		
		JRadioButton mem_prime = new JRadioButton("Prime");
		mem_prime.setBounds(300, 550, 70, 30);
		mem_prime.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				membership_sel = "4";
			}
		});
		membership_gp.add(mem_prime);
		panel.add(mem_prime);
		
		// ��ҹ�ư
		JButton cancel = new JButton("���");
		cancel.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				new loginView();
				dispose();
			}
		});
		cancel.setBounds(250, 650, 100, 30);
		panel.add(cancel);
		
					
		// ȸ������ �Ϸ� ��ư
		JButton finish = new JButton("ȸ������");
		finish.setBounds(100, 650, 100, 30);
		panel.add(finish);
		finish.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
			        mv.stmt = mv.conn.createStatement();	// DB�� ����
			        mv.conn.setAutoCommit(false); 			// auto-commit disabled 
			        String sql = "";
					String sql2 = "";
					
			    	sql = "SELECT ID FROM ACCOUNT";
			        mv.pstmt = mv.conn.prepareStatement(sql);
		            mv.rs = mv.pstmt.executeQuery();
		            
		            int idCount = 1;
		            while(mv.rs.next()) {
		            	if(idCount == Integer.parseInt(mv.rs.getString(1))) {
		            		idCount += 1;
		            		continue;
		            	}
		            	else
		            		break;
		            }
		            
		            System.out.println(idCount);
			        // ������ ����
			        sql2 = "INSERT INTO ACCOUNT VALUES ("
			        	   + idCount + ",'"
			               + idText.getText() + "','"
			               + pwText.getText() + "','"
			               + phoneNbrText.getText() + "','"
			               + nameText.getText() + "','"
			               + jobText.getText() + "','"
			               + birthDateText.getText() + "','"
			               + addressText.getText() + "','"
			               + gender_sel + "',"
			               + "1)" ;
			        if(idText.getText().equals(""))
			        		System.out.println(sql2);

			        int res = mv.stmt.executeUpdate(sql2);
			        mv.conn.commit();
			        
			        // ȸ�����Կ� �������� �� �α��� ȭ������ �̵�
					new loginView();
					dispose();
				} catch (Exception e1) {
					// �ʼ������� ������ �� �˷���
					if(idText.getText().equals("")) 
						idText.setText("�ݵ�� �Է��ؾ��մϴ�.");
					
					if(pwText.getText().equals(""))
						pwText.setText("�ݵ�� �Է��ؾ��մϴ�.");
					
					if(phoneNbrText.getText().equals(""))
						phoneNbrText.setText("�ݵ�� �Է��ؾ��մϴ�.");
					
					if(nameText.getText().equals(""))
						nameText.setText("�ݵ�� �Է��ؾ��մϴ�.");
					
					e1.printStackTrace();
				}

			}
		});
			
		add(panel);
		setSize(500, 800);									// ũ�� ����
		setVisible(true); 									// â�� ���̰� �ϱ�. �⺻�����δ� ������ ����
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);  	// â ������ ���α׷� ����
	}
}