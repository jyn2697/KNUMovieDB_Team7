<7조> - 권혁창, 김주연

[Entity & Attribution]

1. MOVIE
 1) ID(PK, surrogate key) : MOVIE의 기본키
 2) P_C_ID(FK) : 엔터티 (PRODUCTION COMPANY)의 기본키
 3) D_C_ID(FK) : 엔터티 (DISTRIBUTION COMPANY)의 기본키
 4) Title : 영상 제목
 5) Running_Time : 영상의 상영시간
 6) Release_Date : 영상의 개봉일
 7) Maximum_Resolution : 영상의 최고 화질
 8) Viewing_Age : 관람 등급(이용 관람가)
 9) Plot : 영상의 줄거리

2. GENRE
 1) ID(PK, surrogate key) : GENRE의 기본키
 2) Genre_Type : 장르의 종류     ex) Romance, Comedy, etc.

3. RATING
 1) ID(PK, surrogate key) : RATING의 기본키
 2) A_ID(FK) : 엔터티 (ACCOUNT)의 기본키
 3) M_ID(FK) : 엔터티 (MOVIE)의 기본키
 4) Score : 5.0점 만점으로 영화에 대한 점수를 매김
 5) Comment : 영화에 대한 한 줄 평

4. ACTOR
 1) ID(PK, surrogate key) : ACTOR의 기본키
 2) First_Name : 배우의 이름
 3) Last_Name : 배우의 성
 4) Gender : 배우의 성별

4-1. CASTING LIST : 영화와 캐스팅된 배우를 저장
 1) Actor_ID(FK) : 엔터티 (ACTOR)의 기본키
 2) M_ID(FK) : 엔터티 (MOVIE)의 기본키
 3) Type : 주연, 조연 등의 캐스팅 타입을 나타냄

5. EPISODE
 1) ID(PK, surrogate key) : EPISODE의 기본키
 2) M_ID(FK) : 엔터티 (MOVIE)의 기본키
 3) Parent_ID(FK) : 엔터티 (EPISODE)의 기본키
 4) Season_Number : 시즌의 번호
 5) Episode_Number : 해당 시즌 내의 에피소드의 번호
  # 4), 5)은 단편작인 경우 0을 대입

6. VERSION
 1) ID(PK, surrogate key) : VERSION의 기본키
 2) M_ID(FK) : 엔터티 (MOVIE)의 기본키
 3) Country : 국가코드, 서로 다른 버전이 존재하는 나라
 4) Language : 나라에 따른 버전 별 제공 언어
 5) Title_by_country : 국가 별 제목
 6) Is_Origin_Title? : 실제 제목과 같다면 1, 다르다면 0을 반환

7. ACCOUNT
 1) ID(PK, surrogate key) : VERSION의 기본키
 2) PW : 계정의 비밀번호
 3) Phone_Number : 계정주의 전화번호
 4) First_Name : 계정주의 이름
 5) Last_Name : 계정주의 성
 6) Job : 계정주의 직업
 7) Bdate : 계정주의 생년월일
 8) Address : 계정주의 거주지
 9) Gender : 계정주의 성별
 10) Type : 관리자(admin) 계정인지 혹은 고객(customer) 계정인지 저장
 11) Mem_ID(FK) : 고객 계정이라면  MEMBERSHIP 엔터티의 기본키 (id)를 받아옴, 
                              관리자 계정이라면 null을 저장

7-1. MEMBERSHIP : 고객(CUSTOMER)계정에서 MEMBERSHIP 정보를 저장 
                                  (저장공간의 고려 : 수많은 계정에 글대신 숫자의 정보만 저장)
 1) ID(PK, surrogate key) : MEMBERSHIP의 기본키
 2) Type_of_Membership : 유료 멤버십의 종류, 도메인 = {'베이직', '프리미엄', '프라임'}

8. WRITER : 저자의 기본 정보를 담고 있음
 1) ID(PK, surrogate key) : WRITER의 기본키
 2) First _Name : 저자의 이름
 3) Last_Name : 저자의 성

9. DIRECTOR : 감독의 기본 정보를 담고 있음
 1) ID(PK, surrogate key) : DIRECTOR의 기본키
 2) First_Name : 감독의 이름
 3) Last_Name : 감독의 성

10. PRODUCTION_COMPANY : 제작사의 기본 정보를 담고 있음
 1) ID(PK, surrogate key) : PRODUCTION COMPANY의 기본키
 2) Company_Name : 회사 명


11. DISTRIBUTION_COMPANY : 배급사의 기본 정보를 담고 있음
 1) ID(PK, surrogate key) : DISTRIBUTION COMPANY의 기본키
 2) Company_Name : 회사 명

[Relation]

1. GENRES (m:n) : MOVIE와 GENRE사이의 관계
 1) 영화가 어떤 장르를 가지고 있는지 표현
 2) 하나의 영화에는 한개에서 여러개(1:n)의 장르가 표현, 한 장르는 여러 영화와 매칭(1:m)

2. MAKING (m:n) : MOVIE와 PRODUCTION_COMPANY사이의 관계
 1) 영화가 어떤 제작사에 의해 제작되는지 표현
 2) 하나의 영화에는 하나 또는 여러개 제작사가 제작할 수 있음(1:n)
     제작사는 하나 또는 여러개의 영화를 제작할 수 있음(1:n)
  # DB에 저장된 영화를 제작한 회사 이외에는 DB에 저장되지 않는다고 가정 
     -> 저장된 제작사는 무조건 '하나' 이상의 영화를 제작

3. RATION (1:n) : MOVIE와 DISTRIBUTION_COMPANY사이의 관계
 1) 영화가 어떤 배급사에 의해 배급되는지 표현
 2) 하나의 영화에는 하나의 배급사가 배급할 수 있음(1:1)
     배급사는 하나 또는 여러개의 영화를 배급할 수 있음(1:n)

4. CAST (1:n) : MOVIE와 CASTING_LIST 사이의 관계
 1) 배우가 캐스팅된 '영화'를 표현
 2) 한 명의 배우는 여러 영화에 캐스팅 될 수 있음(1:n)

5. APPEAR (1:n) : CASTING LIST과 ACTOR 사이의 관계
 1) 배우가 캐스팅된 영화의 '배우'를 표현
 2) 한 영화는 한명에서 여러명의 배우를 캐스팅 할 수 있음(1:N)
  # '북극의 눈물'같은 배우가 참여하지 않지만 나레이션을 포함한 영화의 경우는 나레이터를 배우로 취급 
 (나레이션은 CASTING의 Type 속성에 표기)

6. CREW_W (m:n) : MOVIE와 WRITER 사이의 관계
 1) 영화가 어떤 작가에 의해 쓰여지는지 표현
 2) 하나의 영화에는 하나 또는 여러명 작가가 참여할 수 있음(1:n)
     작가는 하나 또는 여러개의 영화를 쓸 수 있음(1:n)


7. CREW_D (m:n) : MOVIE와 DIRECTOR 사이의 관계
 1) 영화가 어떤 감독에 의해 연출되는지 표현
 2) 하나의 영화에는 하나 또는 여러명 감독이 연출할 수 있음(1:n)
     감독은 하나 또는 여러개의 영화를 연출할 수 있음(1:n)

8. LIKE (m:n) : MOVIE와 ACCOUNT 사이의 관계
 1) 사용자가 "좋아요" 한 영화를 표현
 2) 하나의 영화에는 하나 또는 여러명의 사용자가 '좋아요' 할 수 있음(1:n)
     사용자는 하나 또는 여러개의 영화에 '좋아요'할 수 있음(1:n) 

9. VIEW (m:n) : MOVIE와 ACCOUNT 사이의 관계
 1) 사용자가 시청한 영화를 표현
 2) 하나의 영화는 하나 또는 여러명의 사용자가 시청할 수 있음(1:n)
     사용자는 하나 또는 여러개의 영화를 시청할 수 있음(1:n)

10. HAVE (1:n) : ACCOUNT와 MEMBERSHIP 사이의 관계
 1) 고객(customer)의 계정인 경우에 유료 membership을 가질 수 있음을 표현
 2) 하나의 고객계정은 하나(멤버쉽 구매) 또는 0개(멤버쉽 구매x)의 멤버쉽정보를 가짐(0:1)
     멤버쉽은 하나 또는 여러명의 고객계정을 할당받을 수 있음(1:n)

11. DETAIL (1:1) : MOVIE와 EPISODE 사이의 관계
 1) 영화의 시리즈와 에피소드를 표현
 2) 하나의 영화는 하나의 시리즈와 에피소드 넘버를 가질 수 있음(1:1)
     하나의 에피소드는 하나의 영화만을 가질 수 있음(1:1)

12. INFORM (1:n) : MOVIE와 VERSION 사이의 관계
 1) 영화와 나라 별 다른 버전에 대해 표현
 2) 하나의 영화는 하나 또는 여러 개의 버전을 가질 수 있음 (1:n)
     각 버전을 대표하는 영화는 한개 뿐임 (1:1)

13. RECEIVE (n:m) : MOVIE와 RATING 사이의 관계
영화와 해당 영화의 평가에 대한 표현
하나의 영화는 하나도 없거나 여러 개의 평가를 가질 수 있음 (0:n)
평가들은 어떠한 영화에도 평가되지 않거나 여러 영화에 평가될 수 있음 (0:n)

14. GIVE (n:m) : ACCOUNT와 RATING 사이의 관계
고객의 영화에 남긴 평가들에 대해 표현
한 명의 고객은 평가를 내리지 않거나 여러 영화에 대해 평가를 내릴 수 있음 (0:n)
한 영화에 대한 평가는 없거나 여러 고객에 의해 내려질 수 있음 (0:n)


## (m:n)의 relation cardinality를 가지는 relation은 relation diagram에서 다른 table로 구현
